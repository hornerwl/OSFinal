class Client {
  public:
    FileSystem *myFS;
    Client(FileSystem *fs){myFS = fs;};
};
